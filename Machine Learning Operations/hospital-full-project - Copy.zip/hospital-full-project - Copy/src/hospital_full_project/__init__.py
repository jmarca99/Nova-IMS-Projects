"""bank_full_project
"""

__version__ = "0.1"
