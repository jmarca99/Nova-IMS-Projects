
"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

from kedro.pipeline import Pipeline, node, pipeline

from .nodes import check_data_drift

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func= check_data_drift,
                inputs=["final_train", "final_X_test"],
                outputs= "data_drift_results",
                name="drift_result",
            ),

        ]
    )
