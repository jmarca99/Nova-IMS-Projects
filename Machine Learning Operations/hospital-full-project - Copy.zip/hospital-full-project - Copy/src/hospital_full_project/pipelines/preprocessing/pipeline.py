
"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

from kedro.pipeline import Pipeline, node, pipeline

from .nodes import all_preprocess, save_data

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [


            node(
                func= all_preprocess,
                inputs=["df", "X_test"],
                outputs= ["train_preprocessed", "X_test_preprocessed", "target_binary"],
                name="all_preprocess",
            ),
            # node(
            #     func=save_data,
            #     inputs=dict(
            #         df="train_preprocessed",  
            #         output_path="params:train_preprocessed_path"  
            #     ),
            #     outputs=None,
            #     name="save_preprocessed_data",
            # ),
            # node(
            #     func=save_data,
            #     inputs=dict(
            #         df="X_test_preprocessed",  
            #         output_path="params:X_test_preprocessed_path"  
            #     ),
            #     outputs=None,
            #     name="save_X_test_preprocessed_data",
            # ),
            # node(
            #     func=save_data,
            #     inputs=dict(
            #         df="target_binary",  
            #         output_path="params:target_binary_path"  
            #     ),
            #     outputs=None,
            #     name="save_target_binary_data",
            # ),
        ]
    )




    #         node(
    #             func=save_data,
    #             inputs=dict(
    #                 train="train_preprocessed",
    #                 X_test="X_test_preprocessed",
    #                 target_binary="target_binary",
    #                 train_path="params:train_preprocessed_path",
    #                 X_test_path="params:X_test_preprocessed_path",
    #                 target_binary_path="params:target_binary_path"
    #             ),
    #             outputs=None,
    #             name="save_preprocessed_data",
    #         ),
    #     ]
    # )