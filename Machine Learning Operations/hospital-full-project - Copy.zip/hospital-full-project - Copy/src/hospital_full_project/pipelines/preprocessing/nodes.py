"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""
import logging
from typing import Any, Dict, Tuple
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import OneHotEncoder , LabelEncoder


from kedro.config import OmegaConfigLoader
from kedro.framework.project import settings

conf_path = str(Path('') / settings.CONF_SOURCE)
conf_loader = OmegaConfigLoader(conf_source=conf_path)
credentials = conf_loader["credentials"]


logger = logging.getLogger(__name__)


"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

import logging
from typing import Any, Dict, Tuple
import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder , LabelEncoder
import seaborn as sns
from sklearn.impute import SimpleImputer
from sklearn.impute import KNNImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import RobustScaler


def prepare_data(df):

    train = df.drop(columns=['readmitted_binary', 'readmitted_multiclass'])
    target_binary = df['readmitted_binary']
    return train, target_binary


def process_data(train, X_test):
    # Step 1: Add hospital_visits column
    train['hospital_visits'] = train.groupby('patient_id')['patient_id'].transform('count')
    X_test['hospital_visits'] = X_test.groupby('patient_id')['patient_id'].transform('count')
    
    # Step 3: Calculate Emergency_visits/total_visits ratio
    train['Emergency_visits/total_visits'] = train['emergency_visits_in_previous_year'] / (
        train['inpatient_visits_in_previous_year'] + train['outpatient_visits_in_previous_year'] + train['emergency_visits_in_previous_year'])
    X_test['Emergency_visits/total_visits'] = X_test['emergency_visits_in_previous_year'] / (
        X_test['inpatient_visits_in_previous_year'] + X_test['outpatient_visits_in_previous_year'] + X_test['emergency_visits_in_previous_year'])
    
    # Step 4: Calculate n_medications/length_of_stay ratio
    train['n_medications/length_of_stay'] = train['number_of_medications'] / train['length_of_stay_in_hospital']
    X_test['n_medications/length_of_stay'] = X_test['number_of_medications'] / X_test['length_of_stay_in_hospital']
    
    return train, X_test


def clean_data(df):
    # Strip whitespace from string values
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    
    # Replace specific placeholder values with NaN
    df.replace('?', np.nan, inplace=True)
    df.replace('Unknown/Invalid', np.nan, inplace=True)
    df.replace(['Not Mapped', 'Not Available'], np.nan, inplace=True)
    
    # Drop the 'country' column if it exists
    if 'country' in df.columns:
        df.drop('country', axis=1, inplace=True)
    
    # Fill NaNs in specific columns with 'Not_tested'
    if 'glucose_test_result' in df.columns:
        df['glucose_test_result'].fillna('Not_tested', inplace=True)
    if 'a1c_test_result' in df.columns:
        df['a1c_test_result'].fillna('Not_tested', inplace=True)
    
    # Map 'payer_code' column: NaN to 0, others to 1
    if 'payer_code' in df.columns:
        df['payer_code'] = df['payer_code'].map(lambda x: 0 if pd.isna(x) else 1)
    
    return df

def process_age_column(df):
    def col_age(age):
        if not pd.isna(age):
            new_value = age.split('-')
            age_1 = int(new_value[0].strip('['))
            age_2 = int(new_value[1].strip(')'))
            return (age_1 + age_2) / 2
        else:
            return np.nan
    
    if 'age' in df.columns:
        df['age'] = df['age'].apply(col_age)
    
    return df

def drop_newborn_outliers(df, target_df):
    # Find indices to drop
    to_drop = df[(df['admission_type'] == 'Newborn') & (df['age'] > 5)].index.to_list()
    # Drop rows in the main DataFrame
    df.drop(to_drop, inplace=True)
    # Drop rows in the target DataFrame
    target_df.drop(to_drop, inplace=True)
    return df, target_df

def drop_newborn_outliers1(df):
    # Find indices to drop
    to_drop = df[(df['admission_type'] == 'Newborn') & (df['age'] > 5)].index.to_list()
    # Drop rows in the main DataFrame
    df.drop(to_drop, inplace=True)
    return df

def fill_missing_age(train, test):
    # Fill missing 'age' values in train set
    train['age'] = train.groupby('patient_id')['age'].transform(lambda x: x.fillna(x.mean()))
    # Calculate mean age per patient
    train_patient_means = train.groupby('patient_id')['age'].mean()
    # Fill missing 'age' values in test set using train's patient means
    test['age'] = test['patient_id'].map(train_patient_means).where(test['age'].isnull(), test['age'])
    return train, test

def fill_missing_race(train, test):
    # Fill missing 'race' values in train set
    train['race'] = train.groupby('patient_id')['race'].transform(lambda x: x.fillna(x.mode().iloc[0] if not x.mode().empty else np.nan))
    # Calculate mode race per patient
    modes = train.groupby('patient_id')['race'].apply(lambda x: x.mode().iloc[0] if not x.mode().empty else np.nan)
    # Fill missing 'race' values in test set using train's patient modes
    test['race'] = test['patient_id'].map(modes).where(test['race'].isnull(), test['race'])
    return train, test

def impute_missing_values(train, test):
    # Impute missing values for numeric columns with mean
    numeric = train.select_dtypes(include=np.number).columns
    imputer_numeric = SimpleImputer(strategy='mean')
    imputer_numeric.fit(train[numeric])
    train[numeric] = imputer_numeric.transform(train[numeric])
    test[numeric] = imputer_numeric.transform(test[numeric])
    
    # Impute missing values for categorical columns with the most frequent value
    object_columns = train.select_dtypes(include=['object']).columns
    imputer_object = SimpleImputer(strategy='most_frequent')
    imputer_object.fit(train[object_columns])
    train[object_columns] = imputer_object.transform(train[object_columns])
    test[object_columns] = imputer_object.transform(test[object_columns])
    
    return train, test

def map_icd9_to_category(df):
    def icd9_to_category(icd9):
        if not pd.isna(icd9):
            if icd9[0] == 'E' or icd9[0] == 'V':
                return 'other health factors and external causes'
            else:
                icd9 = float(icd9)
                if icd9 >= 1 and icd9 <= 139:
                    return 'infectious and parasitic diseases'
                elif icd9 >= 140 and icd9 <= 239:
                    return 'neoplasms'
                elif icd9 >= 240 and icd9 <= 279:
                    return 'diabetes, endocrine and metabolic disorders'
                elif icd9 >= 280 and icd9 <= 289:
                    return 'other diseases/conditions'
                elif icd9 >= 290 and icd9 <= 319:
                    return 'mental disorders'
                elif icd9 >= 320 and icd9 <= 389:
                    return 'other diseases/conditions'
                elif icd9 >= 390 and icd9 <= 459:
                    return 'circulatory system diseases'
                elif icd9 >= 460 and icd9 <= 519:
                    return 'respiratory system diseases'
                elif icd9 >= 520 and icd9 <= 579:
                    return 'digestive system diseases'
                elif icd9 >= 580 and icd9 <= 629:
                    return 'genitourinary system diseases'
                elif icd9 >= 630 and icd9 <= 679:
                    return 'other diseases/conditions'
                elif icd9 >= 680 and icd9 <= 709:
                    return 'skin diseases'
                elif icd9 >= 710 and icd9 <= 739:
                    return 'musculoskeletal disorders'
                elif icd9 >= 740 and icd9 <= 759:
                    return 'other diseases/conditions'
                elif icd9 >= 760 and icd9 <= 779:
                    return 'perinatal conditions'
                elif icd9 >= 780 and icd9 <= 799:
                    return 'uncertain conditions'
                elif icd9 >= 800 and icd9 <= 999:
                    return 'injury and poisoning'
                elif icd9 == 0:
                    return 'None'
        else:
            return np.nan
    
    columns_to_map = ['primary_diagnosis', 'secondary_diagnosis', 'additional_diagnosis']
    for col in columns_to_map:
        df[col] = df[col].apply(icd9_to_category)
    
    return df

def create_diagnosis_columns(train, X_test):
    # Step 1: Generate unique diagnosis values
    diagnosis_values = train['primary_diagnosis'].unique().tolist() + \
                       train['secondary_diagnosis'].unique().tolist() + \
                       train['additional_diagnosis'].unique().tolist()
    diagnosis_values = list(set(diagnosis_values))
    
    # Step 2: Create binary columns for each unique diagnosis value in train
    for i in diagnosis_values:
        train['diagnosis_' + i] = (train['primary_diagnosis'].str.contains(i) | 
                                    train['secondary_diagnosis'].str.contains(i) | 
                                    train['additional_diagnosis'].str.contains(i)).astype(int)
    
    # Drop original diagnosis columns from train
    train.drop(['primary_diagnosis', 'secondary_diagnosis', 'additional_diagnosis'], axis=1, inplace=True)
    
    # Step 3: Create binary columns for each unique diagnosis value in X_test
    for i in diagnosis_values:
        X_test['diagnosis_' + i] = (X_test['primary_diagnosis'].str.contains(i) | 
                                    X_test['secondary_diagnosis'].str.contains(i) | 
                                    X_test['additional_diagnosis'].str.contains(i)).astype(int)
    
    # Drop original diagnosis columns from X_test
    X_test.drop(['primary_diagnosis', 'secondary_diagnosis', 'additional_diagnosis'], axis=1, inplace=True)
    
    return train, X_test


def map_categorical_to_numeric(train, X_test, target_binary=None):
    # Mapping for 'gender'
    train['gender'] = train['gender'].map({'Male': 0, 'Female': 1})
    X_test['gender'] = X_test['gender'].map({'Male': 0, 'Female': 1})
  
    # Mapping for 'change_in_meds_during_hospitalization'
    train['change_in_meds_during_hospitalization'] = train['change_in_meds_during_hospitalization'].map({'No': 0, 'Ch': 1})
    X_test['change_in_meds_during_hospitalization'] = X_test['change_in_meds_during_hospitalization'].map({'No': 0, 'Ch': 1})
    
    # Mapping for 'prescribed_diabetes_meds'
    train['prescribed_diabetes_meds'] = train['prescribed_diabetes_meds'].map({'No': 0, 'Yes': 1})
    X_test['prescribed_diabetes_meds'] = X_test['prescribed_diabetes_meds'].map({'No': 0, 'Yes': 1})
    
    # Mapping for target_binary (if provided)
    if target_binary is not None:
        target_binary = target_binary.map({'No': 0, 'Yes': 1})
   
    return train, X_test, target_binary


def label_encode_admission_type(train, X_test):
    # Define the mapping based on the specified order
    admission_type_mapping = {'Emergency': 1, 'Urgent': 2, 'Elective': 3, 'Newborn': 4, 'Trauma Center': 5}
    
    # Apply the mapping to 'admission_type' column in train and X_test
    train['admission_type'] = train['admission_type'].map(admission_type_mapping)
    X_test['admission_type'] = X_test['admission_type'].map(admission_type_mapping)
    
    return train, X_test


def map_admission_source(train, X_test):
    # Define the mapping function for 'admission_source' column
    map_func = lambda x: 'Transfer from Another Health Facility' if 'Transfer' in x else x
    
    # Apply the mapping function to 'admission_source' column in train and X_test
    train['admission_source'] = train['admission_source'].map(map_func)
    X_test['admission_source'] = X_test['admission_source'].map(map_func)
    
    return train, X_test


def one_hot_encode_and_combine(train, X_test):
    # Step 1: Identify categorical columns
    obj_cols = train.select_dtypes(include=['object']).columns.tolist()
    
    # Step 2: Initialize OneHotEncoder
    encoder = OneHotEncoder(handle_unknown='ignore', sparse=False)
    
    # Step 3: Fit and transform on train
    X_train_encoded_bm = encoder.fit_transform(train[obj_cols])
    
    # Step 4: Transform X_test
    X_test_encoded_bm = encoder.transform(X_test[obj_cols])
    
    # Step 5: Get feature names after encoding
    encoded_columns = encoder.get_feature_names_out(obj_cols)
    
    # Step 6: Create DataFrames for encoded features
    X_train_encoded_bm_df = pd.DataFrame(X_train_encoded_bm, columns=encoded_columns, index=train.index)
    X_test_encoded_bm_df = pd.DataFrame(X_test_encoded_bm, columns=encoded_columns, index=X_test.index)
    
    # Step 7: Drop original categorical columns from train and X_test
    X_train_num = train.drop(obj_cols, axis=1)
    X_test_num = X_test.drop(obj_cols, axis=1)
    
    # Concatenate numeric and encoded categorical DataFrames
    train = pd.concat([X_train_num, X_train_encoded_bm_df], axis=1)
    X_test = pd.concat([X_test_num, X_test_encoded_bm_df], axis=1)
    
    return train, X_test


def drop_patient_id_column(train, X_test):
    # Drop 'patient_id' column from train and X_test
    train.drop('patient_id', axis=1, inplace=True)
    X_test.drop('patient_id', axis=1, inplace=True)
    
    return train, X_test


def scale_numerical_columns(train, X_test):
    # Step 1: Identify numerical columns
    numerical = train.select_dtypes(include=np.number).columns.tolist()
    
    # Step 2: Count unique values for each numerical column
    cat = {col: train[col].nunique() for col in numerical}
    
    # Step 3: Categorize columns into non-binary and binary
    non_binary = [col for col in cat if cat[col] != 2]
    binary = [col for col in cat if cat[col] == 2]
    
    # Step 4: Initialize RobustScaler
    scaler = RobustScaler()
    
    # Step 5: Fit and transform non-binary columns on train, and transform on X_test
    train.loc[:, non_binary] = scaler.fit_transform(train[non_binary])
    X_test.loc[:, non_binary] = scaler.transform(X_test[non_binary])
    
    return train, X_test


def all_preprocess(df, X_test):
     # Step 1: Prepare data
     train, target_binary = prepare_data(df)
   
     # Step 2: Process data
     train, X_test = process_data(train, X_test)
    
     # Step 3: Clean data
     train = clean_data(train)
     X_test = clean_data(X_test)
    
     # Step 4: Process age column
     train = process_age_column(train)
     X_test = process_age_column(X_test)
    
     # Step 5: Drop newborn outliers
     train, target_binary = drop_newborn_outliers(train, target_binary)
     X_test = drop_newborn_outliers1(X_test)
    
     # Step 6: Fill missing age
     train, X_test = fill_missing_age(train, X_test)
    
     # Step 7: Fill missing race
     train, X_test = fill_missing_race(train, X_test)
    
     # Step 8: Impute missing values
     train, X_test = impute_missing_values(train, X_test)
    
     # Step 9: Map ICD-9 to category
     train = map_icd9_to_category(train)
     X_test = map_icd9_to_category(X_test)
    
     # Step 10: Create diagnosis columns
     train, X_test = create_diagnosis_columns(train, X_test)
    
     # Step 11: Map categorical to numeric
     train, X_test, target_binary = map_categorical_to_numeric(train, X_test, target_binary)
    
     # Step 12: Label encode admission type
     train, X_test = label_encode_admission_type(train, X_test)
    
     # Step 13: Map admission source
     train, X_test = map_admission_source(train, X_test)
    
     # Step 14: One-hot encode and combine
     train, X_test = one_hot_encode_and_combine(train, X_test)
    
     # Step 15: Drop patient ID column
     train, X_test = drop_patient_id_column(train, X_test)
    
     # Step 16: Scale numerical columns
     train, X_test = scale_numerical_columns(train, X_test)

     train_preprocessed = train
     X_test_preprocessed = X_test

     return train_preprocessed, X_test_preprocessed, target_binary


def save_data(df: pd.DataFrame, output_path: str):
    df.to_csv(output_path, index=False)
    return df


