
"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import return_raw_data

def create_pipeline() -> Pipeline:
    return pipeline(
        [
            node(
                func=return_raw_data,
                inputs=None,
                outputs=["df", "X_test"],
                name="ingest_raw_data"
            )
        ]
    )
