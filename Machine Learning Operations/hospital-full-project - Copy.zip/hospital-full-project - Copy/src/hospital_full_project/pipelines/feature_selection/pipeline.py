
"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

from kedro.pipeline import Pipeline, node, pipeline

from .nodes import select_features_with_models


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=select_features_with_models,
                inputs=["train_preprocessed", "X_test_preprocessed", "target_binary"],
                outputs=["final_train", "final_X_test"],
                name="feature_selection",
            ),
        ]
    )
