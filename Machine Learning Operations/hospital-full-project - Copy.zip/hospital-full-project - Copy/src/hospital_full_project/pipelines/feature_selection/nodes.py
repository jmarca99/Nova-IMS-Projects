import logging
from typing import Any, Dict, Tuple
import numpy as np
import pandas as pd
import json
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import OneHotEncoder , LabelEncoder
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, classification_report
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
import os
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LassoCV


def select_features_with_models(train, X_test, target_binary):
    # Step 1: Random Forest Feature Importance
    rf_model = RandomForestClassifier(class_weight='balanced', random_state=42, max_depth=6, n_jobs=-1)
    rf_model.fit(train, target_binary)
    
    feature_importances = rf_model.feature_importances_
    feature_importance_df = pd.DataFrame({'Feature': train.columns, 'Importance': feature_importances})
    feature_importance_df = feature_importance_df.sort_values(by='Importance', ascending=False)
    sorted_indices = np.argsort(feature_importances)[::-1]
    top_30_features = sorted_indices[:30]
    selected_features = train.columns[top_30_features]
    
    selected = {}
    for i in selected_features:
        selected[i] = 1
    
    # Step 2: RFE with Random Forest took more than 10 minutes to run and it always returned the following 2 features
    selected_features = ['inpatient_visits_in_previous_year', 'hospital_visits']
    for i in selected_features:
        if i in selected.keys():
            selected[i] += 1
        else:
            selected[i] = 1
    
    # Step 3: Lasso Feature Selection
    reg = LassoCV().fit(train, target_binary)
    coef = pd.Series(reg.coef_, index=train.columns)
    print("Lasso picked " + str(sum(coef != 0)) + " variables and eliminated the other " +  str(sum(coef == 0)) + " variables")
    
    lasso_features = coef[coef != 0].index.tolist()
    for i in lasso_features:
        if i in selected.keys():
            selected[i] += 1
        else:
            selected[i] = 1
    
    # Step 4: Select features to keep
    keep = [i for i in selected.keys() if selected[i] >= 2]
    
    # Step 5: Subset train and X_test DataFrames
    final_train = train[keep]
    final_X_test = X_test[keep]
    
    return final_train, final_X_test