"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

import logging
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import SimpleImputer
from sklearn.impute import KNNImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import RobustScaler

from pathlib import Path

from kedro.config import OmegaConfigLoader
from kedro.framework.project import settings

# Function to perform data validation
def data_test(df):
    # Define the columns and their expected data types
    columns_to_check = {
        "country": "object",
        "patient_id": "int64",
        "race": "object",
        "gender": "object",
        "age": "object",
        "weight": "object",
        "payer_code": "object",
        "outpatient_visits_in_previous_year": "int64",
        "emergency_visits_in_previous_year": "int64",
        "inpatient_visits_in_previous_year": "int64",
        "admission_type": "object",
        "medical_specialty": "object",
        "average_pulse_bpm": "int64",
        "discharge_disposition": "object",
        "admission_source": "object",
        "length_of_stay_in_hospital": "int64",
        "number_lab_tests": "int64",
        "non_lab_procedures": "int64",
        "number_of_medications": "int64",
        "primary_diagnosis": "object",
        "secondary_diagnosis": "object",
        "additional_diagnosis": "object",
        "number_diagnoses": "int64",
        "glucose_test_result": "object",
        "a1c_test_result": "object",
        "change_in_meds_during_hospitalization": "object",
        "prescribed_diabetes_meds": "object",
        "medication": "object",
        "readmitted_binary": "object",
        "readmitted_multiclass": "object"
    }

    validation_results = []

    # Function to check data types
    def check_data_types(df, columns_to_check):
        for column, expected_dtype in columns_to_check.items():
            actual_dtype = df[column].dtype
            success = actual_dtype == expected_dtype
            error = "" if success else f"Data type mismatch: expected '{expected_dtype}', got '{actual_dtype}'"
            validation_results.append({
                "Column": column,
                "Check": "Data Type",
                "Expected": expected_dtype,
                "Actual": actual_dtype,
                "Success": success,
                "Error": error
            })

    # Function to check for nulls
    def check_for_nulls(df, columns_to_check):
        for column, expected_dtype in columns_to_check.items():
            null_count = df[column].isnull().sum()
            success = null_count == 0
            error = "" if success else f"Null values found: {null_count}"
            validation_results.append({
                "Column": column,
                "Check": "Null Values",
                "Expected": "No Nulls",
                "Actual": f"Nulls: {null_count}",
                "Success": success,
                "Error": error
            })

    # Function to check specific conditions
    def check_custom_conditions(df):
        readmitted_binary_check = set(df['readmitted_binary']).issubset({'No', 'Yes'})
        validation_results.append({
            "Column": "readmitted_binary",
            "Check": "Value Set",
            "Expected": "{'No', 'Yes'}",
            "Actual": set(df['readmitted_binary']),
            "Success": readmitted_binary_check,
            "Error": "" if readmitted_binary_check else "Unexpected values found"
        })

        gender_check = set(df['gender']).issubset({'Female', 'Male', 'Unknown/Invalid'})
        validation_results.append({
            "Column": "gender",
            "Check": "Value Set",
            "Expected": "{'Female', 'Male', 'Unknown/Invalid'}",
            "Actual": set(df['gender']),
            "Success": gender_check,
            "Error": "" if gender_check else "Unexpected values found"
        })

        age_regex_check = df['age'].str.match(r'\[([0-9]+)-([0-9]+)\)').all()
        validation_results.append({
            "Column": "age",
            "Check": "Regex Match",
            "Expected": "[age range regex]",
            "Actual": df['age'].unique(),
            "Success": age_regex_check,
            "Error": "" if age_regex_check else "Values do not match regex"
        })

    # Perform the checks
    check_data_types(df, columns_to_check)
    check_for_nulls(df, columns_to_check)
    check_custom_conditions(df)

    # Create a summary table
    validation_summary = pd.DataFrame(validation_results)

    return validation_summary